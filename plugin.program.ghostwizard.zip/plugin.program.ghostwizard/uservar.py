# coding: utf-8
import os, xbmc, xbmcaddon

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'GHOST WIZARD' 
EXCLUDES       = [ADDON_ID, 'repository.utv']
BUILDFILE      = 'https://pastebin.com/hEqiLDwq'
TMDB_NEW_API = 'aG9qaw=='
UPDATECHECK    = 0
APKFILE        = ''
YOUTUBETITLE   = ''
YOUTUBEFILE    = ''
ADDONFILE      = ''
ADVANCEDFILE   = ''
PASS		   = 'https://pastebin.com/raw/kKCPtD7c'
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

ICONBUILDS     = 'http://'
ICONMAINT      = 'http://'
ICONAPK        = 'http://'
ICONADDONS     = 'http://'
ICONYOUTUBE    = 'http://'
ICONSAVE       = 'http://'
ICONTRAKT      = 'http://'
ICONREAL       = 'http://'
ICONLOGIN      = 'http://'
ICONCONTACT    = 'http://'
ICONSETTINGS   = 'http://'
HIDESPACERS    = 'Yes'
SPACER         = '*'

COLOR1         = 'green'
COLOR2         = 'yellow'

THEME1         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
THEME4         = '[COLOR '+COLOR1+']%s[/COLOR] [COLOR '+COLOR2+']גירסת בילד:[/COLOR]'
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'

HIDECONTACT    = 'No'
CONTACT        = ''
CONTACTICON    = 'http://'
CONTACTFANART  = 'http://'

AUTOUPDATE     = 'Yes'
WIZARDFILE     = 'https://pastebin.com/raw/xT5cxkiZ'


AUTOINSTALL    = 'No'
REPOID         = ''
REPOADDONXML   = ''
REPOZIPURL	   = ''

ENABLE         = 'Yes'
NOTIFICATION   = 'https://pastebin.com/raw/uY5siT35'
ENABLE2			= 'Yes'
NOTIFICATION2   = 'https://pastebin.com/raw/uY5siT35'
ENABLE3			= 'No'
NOTIFICATION3	= ''
HEADERTYPE     = 'Image'
HEADERMESSAGE  =  'מה חדש?'
HEADERIMAGE    = 'https://i.imgur.com/gu3akii.jpg'
BACKGROUND     = 'https://euimages.urbanoutfitters.com/is/image/UrbanOutfittersEU/5123433451032_001_s'
